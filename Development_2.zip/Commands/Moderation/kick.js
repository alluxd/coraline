const {
    CommandInteraction,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    SlashCommandBuilder,
    PermissionFlagsBits,
} = require('discord.js')


module.exports = {
    data: new SlashCommandBuilder()
        .setName('kick')
        .setDescription('Kick a user from the server.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to kick.')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName("reason")
                .setDescription("Reason for kicking this user (optional).")
                .setRequired(false)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
    async execute(interaction, client) {
        const { options, channel } = interaction;




        const user = options.getUser("user")
        const reason = options.getString("reason") || 'No reason was specified.'
        const member = await interaction.guild.members.fetch(user.id)
        const botuser = interaction.guild.members.fetch(client.user.id)


        const errEmbed = new EmbedBuilder()
            .setDescription(`:x: Your highest role is less than or equal to ${member}'s highest role.`)
            .setColor("Red")

        const errEmbed2 = new EmbedBuilder()
            .setDescription(`:x:${member}'s highest role is above or equal to my highest role, therefore I can't kick this user.`)
            .setColor("Red")

        const errEmbed3 = new EmbedBuilder()
            .setDescription(`:x: Please ensure that I have the permission "Kick Members".`)
            .setColor("Red")

        const kickMsg = new EmbedBuilder()
            .setTitle(":hammer: You were kicked!")
            .setDescription(`:hammer: You were kicked from '${interaction.guild.name}' \n ❔ Reason: ${reason} \n 🎭 Responsible Moderator: ${interaction.user.tag}`)
            .setColor('Red')

            if (member.roles.highest.position >= interaction.member.roles.highest.position) {
                return interaction.reply({ embeds: [errEmbed] })
            }
    
            if (client.user.permissions.has(PermissionFlagsBits.KickMembers, false)) {
                return await interaction.reply({ embeds: [errEmbed3] })
            }
    
            if (member.roles.highest.position >= client.user.roles.highest.position) {
                return interaction.reply({ embeds: [errEmbed] })
            }


        await member.send({ embeds: [kickMsg] })
        await member.kick(reason)

       

        const successEmbed = new EmbedBuilder()
            .setDescription(`:white_check_mark: Kicked ${user.tag} with reason: ${reason} successfully!`)
            .setColor("Green")


        await interaction.reply({
            embeds: [successEmbed]
        })



    }
}