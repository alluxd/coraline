# Coraline
## Discord bot built using discord.js for Allu's Lounge


# Features
- New commands almost every day!
- Fast responses
- AI-Based Commands
  

# Credits
[@AlluXD](https://youtube.com/@alluxd)
[@kajdev (handlers)](https://youtube.com/@kajdev)
